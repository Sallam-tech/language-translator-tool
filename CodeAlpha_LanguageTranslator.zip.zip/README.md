# 🌐 Language Translator Tool

This is a simple Python-based language translator tool that uses the `googletrans` library to translate text into different languages.

## 🔧 Features
- Automatically detects the input language
- Allows translation to any supported language (e.g., Urdu, French, Spanish)
- Console-based interface
- No API key required

## 📦 Requirements
Install required packages using:

```
pip install -r requirements.txt
```

## 🚀 How to Run

```
python translator.py
```

## 🧪 Example

```
Enter text to translate: Hello, how are you?
Enter target language (e.g., 'fr' for French): ur
🗣️ Translated Text: ہیلو، آپ کیسے ہیں؟
```

## 📌 Notes
This project was developed as part of my internship at Internee.pk.
