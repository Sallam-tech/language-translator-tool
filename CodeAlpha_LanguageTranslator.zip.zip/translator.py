from googletrans import Translator

def translate_text(text, dest_language):
    translator = Translator()
    translated = translator.translate(text, dest=dest_language)
    return translated.text

def main():
    print("🌍 Language Translator Tool | Type 'exit' to quit.")
    while True:
        text = input("\nEnter text to translate: ")
        if text.lower() == 'exit':
            print("Goodbye!")
            break
        dest_language = input("Enter target language (e.g., 'fr' for French, 'ur' for Urdu, 'es' for Spanish): ")
        try:
            result = translate_text(text, dest_language)
            print("🗣️ Translated Text:", result)
        except Exception as e:
            print("Error:", e)

if __name__ == "__main__":
    main()
